const searchInput = document.querySelector('.search-input');
        const searchButton = document.querySelector('.search-button');

        searchButton.addEventListener('click', () => {
            const query = searchInput.value;
            console.log('Search query:', query);
        });

        const gallery = document.querySelector(".gallery");
        const prevButton = document.querySelector(".prev-button");
        const nextButton = document.querySelector(".next-button");
        const dotsContainer = document.querySelector(".dots");
        
        const slides = gallery.querySelectorAll("img");
        let currentIndex = 0;
        
        function showSlide(index) {
            slides.forEach((slide, i) => {
                if (i === index) {
                    slide.style.display = "block";
                } else {
                    slide.style.display = "none";
                }
            });
            updateDots(index);
        }
        
        function prevSlide() {
            currentIndex = (currentIndex - 1 + slides.length) % slides.length;
            showSlide(currentIndex);
        }
        
        function nextSlide() {
            currentIndex = (currentIndex + 1) % slides.length;
            showSlide(currentIndex);
        }
        
        function createDots() {
            slides.forEach((_, index) => {
                const dot = document.createElement("div");
                dot.classList.add("dot");
                dot.addEventListener("click", () => {
                    currentIndex = index;
                    showSlide(currentIndex);
                });
                dotsContainer.appendChild(dot);
            });
        }
        
        function updateDots(index) {
            const dots = dotsContainer.querySelectorAll(".dot");
            dots.forEach((dot, i) => {
                if (i === index) {
                    dot.classList.add("active");
                } else {
                    dot.classList.remove("active");
                }
            });
        }
        
        prevButton.addEventListener("click", prevSlide);
        nextButton.addEventListener("click", nextSlide);
        
        showSlide(currentIndex);
        createDots();
